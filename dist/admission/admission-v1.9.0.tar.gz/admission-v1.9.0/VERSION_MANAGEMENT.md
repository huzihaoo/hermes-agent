# Admission Control — Version Management Quick Reference

## 当前版本

```python
from gateway.admission import __version__
print(__version__)  # "1.9.0"
```

## 查看版本历史

```bash
# 完整 CHANGELOG
cat gateway/admission/CHANGELOG.md

# 哪些文件在哪个版本被改过
grep -r "Changed in: v" gateway/admission/*.py

# Git 历史
git log --oneline -- gateway/admission/
```

## 升版本流程

### 1. 评估变更范围

| 变更类型 | 版本号变化 | 示例 |
|---------|-----------|------|
| Bug fix / 并发修复 / 小优化 | PATCH +1 | 1.0.0 → 1.0.1 |
| 新功能 / 新 lane / 新配置项 | MINOR +1 | 1.0.1 → 1.1.0 |
| 破坏性变更 / 数据迁移 | MAJOR +1 | 1.1.0 → 2.0.0 |

### 2. 实施变更

```bash
# 在源文件头部注入版本标记
# 示例：queue.py
"""...
Changed in: v1.0.1 — _gc_empty_domain_id race fix
"""
```

### 3. 验证

```bash
cd /Users/songying/.hermes/hermes-agent
source venv/bin/activate

# 跑完整 admission 测试套件
python -m pytest tests/gateway/test_admission*.py tests/gateway/test_feishu_admission_autostart.py -q -o 'addopts='

# 确认通过
# Expected: XX passed, 0 failed
```

### 4. 更新版本记录

```bash
# 1. 更新 __init__.py
vim gateway/admission/__init__.py
# 修改 __version__ = "1.0.2"
# 在 docstring 的 Version History 中追加新版本

# 2. 更新 CHANGELOG.md
vim gateway/admission/CHANGELOG.md
# 在顶部追加新版本段落

# 3. 在修改的源文件头部注入版本标记
# 示例：
# Changed in: v1.0.2 — 描述
```

### 5. Git Commit

```bash
git add gateway/admission/
git commit -m "feat(admission): v1.0.2 — 简短描述

详细变更：
- 修复了 X
- 新增了 Y
- 优化了 Z

Tests: XX/XX passed"
```

## 版本号语义

```
1.0.1
│ │ └─ PATCH: 向后兼容的 bug fix
│ └─ MINOR: 向后兼容的新功能
└─ MAJOR: 破坏性变更
```

## 快速检查

```bash
# 当前版本
python3 -c "from gateway.admission import __version__; print(__version__)"

# 最近 5 次 admission 相关提交
git log --oneline -5 -- gateway/admission/

# 测试覆盖率
python -m pytest tests/gateway/test_admission*.py tests/gateway/test_feishu_admission_autostart.py --cov=gateway.admission --cov-report=term-missing -o 'addopts='
```

## 回滚到旧版本

```bash
# 查看历史版本
git log --oneline -- gateway/admission/__init__.py

# 回滚到特定 commit
git checkout <commit-hash> -- gateway/admission/

# 验证
python -m pytest tests/gateway/test_admission*.py tests/gateway/test_feishu_admission_autostart.py -q -o 'addopts='
```

## 版本兼容性矩阵

| admission 版本 | hermes-agent 版本 | Python | SQLite | 备注 |
|---------------|------------------|--------|--------|------|
| 1.0.0 - 1.0.1 | 0.9.0+ | 3.11+ | 3.35+ | 基础队列 + 域隔离 |
| 1.1.0 | 0.9.0+ | 3.11+ | 3.35+ | 告警规则 |
| 1.2.0 | 0.9.0+ | 3.11+ | 3.35+ | 策略模板 |
| 1.3.0 | 0.9.0+ | 3.11+ | 3.35+ | 边界测试 + ConnectionPool |
| 1.4.0 | 0.9.0+ | 3.11+ | 3.35+ | Prometheus exporter |
| 1.5.0 | 0.9.0+ | 3.11+ | 3.35+ | MetricsServer + CLI alerts/apply |
| 1.6.0 | 0.9.0+ | 3.11+ | 3.35+ | FeishuAdapter 自动集成 MetricsServer/template |
| 1.7.0 | 0.9.0+ | 3.11+ | 3.35+ | Gateway 启动防护，杜绝进程堆积 |
| 1.8.0 | 0.10.0+ | 3.11+ | 3.35+ | VM 仓库多用户 worktree 隔离 + 审计 |
| 1.9.0 | 0.10.0+ | 3.11+ | 3.35+ | Feishu 任务话题反馈路由闭环 + request_message_id 持久化 |

## 下一版本规划

查看 `CHANGELOG.md` 底部的 "待办（下一版本候选）" 章节。
